xor linked list is a memory-efficient doubly linked list.
It can implement a doubly linked by the node that only have two member(data and link), but not three(data,prev,next)
because each node is the exclusive OR of the addresses of the nodes to its left and right.
insert it by the function newnode() and the printing it by the function traverse().
both using the xor operator "^" to points the address.
