===MAZE===
Using stack to save the posible step,
if there are no posible next step,
pop() from the stack (go back to the previous step)
and find the next posible step and push().
loop it until the next step is 'd'.